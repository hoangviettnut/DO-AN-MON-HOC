#include <16F877A.h>
#FUSES hs
#use delay(clock=8000000)
#define LCD_RS_PIN      PIN_E0
#define LCD_RW_PIN      PIN_E1
#define LCD_ENABLE_PIN  PIN_E2
#define LCD_DATA4       PIN_D4
#define LCD_DATA5       PIN_D5
#define LCD_DATA6       PIN_D6
#define LCD_DATA7       PIN_D7
#include <lcd.c>
#define trig PIN_B5
#define BUTTON_UP PIN_D0   // n�t nh?n
#define BUTTON_DOWN PIN_D1 // n�t nh?n
#define VIEW_BUTTON PIN_D2 // �?nh ngh?a ch�n D2 l� n�t xem
#define BUZZER_PIN PIN_D3  // loa

int thiet_lap = 150; // kho?ng c�ch thi?t l?p m?c �?nh

void do_dac();
int16 khoang_cach;
int32 kc32;
int8 kcl, kch;
unsigned int16 khoang_cach_luu; // bi?n l�u kho?ng c�ch �o ��?c
unsigned int16 thoi_gian_luu; // bi?n �?m th?i gian l�u

#define SO_KHOANG_CACH_LUU 20
unsigned int16 khoang_cach_da_luu[SO_KHOANG_CACH_LUU]; // m?ng l�u 20 l?n �o cu?i c�ng
int chi_so_hien_tai = 0; // ch? s? hi?n t?i trong m?ng

void luu_khoang_cach(unsigned int16 kc32) {
  khoang_cach_da_luu[chi_so_hien_tai] = kc32;
  chi_so_hien_tai++;
  if (chi_so_hien_tai >= SO_KHOANG_CACH_LUU) {
    chi_so_hien_tai = 0; // v?ng l?i �?u m?ng
  }
}

void xem_khoang_cach_da_luu() {
  for (int j = 0; j < SO_KHOANG_CACH_LUU; j++) {
    lcd_putc('\f'); // x�a m�n h?nh
    lcd_gotoxy(3, 1);
    lcd_putc("NHUNG LAN DO");
    lcd_gotoxy(1, 2); // hi?n th? ? d?ng th? 2
    printf(lcd_putc, "LAN %2u : %3Lu MM", j + 1, khoang_cach_da_luu[j]); // s?a l?i �?nh d?ng
    delay_ms(1000); // hi?n th? trong 1 gi�y
  }
  lcd_putc('\f');
  lcd_gotoxy(1, 1); // ��a lcd v? d?ng 1 c?t 1 
  printf(lcd_putc, "DISTANCE: ");
}

void main() {
  thoi_gian_luu = 0; // kh?i t?o b? �?m th?i gian l�u
  enable_interrupts(global); // cho ph�p ng?t to�n c?c 
  setup_timer_0(RTCC_DIV_2 | RTCC_INTERNAL); // c�i �?t timer 0 ph?c v? �o kho?ng c�ch
  ext_int_edge(H_TO_L); // ng?t c?nh xu?ng // d�ng �? �?c c?m bi?n
  lcd_init(); // kh?i t?o LCD
  lcd_gotoxy(1, 1); // ��a lcd v? d?ng 1 c?t 1 
  printf(lcd_putc, "HE THONNG NHUNG");
  delay_ms(1000);
  lcd_gotoxy(1, 2); // ��a lcd v? d?ng 2 c?t 1
  printf(lcd_putc, "   DO AN HTN"); // hi?n th? kho?ng c�ch l�n lcd
  delay_ms(1000);
  lcd_putc('\f');
  lcd_gotoxy(1, 1); // ��a lcd v? d?ng 1 c?t 1 
  printf(lcd_putc, "DISTANCE: ");
  set_timer0(-12);
  int16 of;
  setup_timer_0(RTCC_INTERNAL | RTCC_DIV_4); // 0-255 tr�n 51.2us
  do_dac();
  of = khoang_cach;
   
  while (true) // v?ng l?p v� h?n
  {
    if (input(BUTTON_UP) == 0) {
      thiet_lap+=10;  
      delay_ms(100); // ch?ng nhi?u khi nh?n n�t
    }

    if (input(BUTTON_DOWN) == 0) {
      thiet_lap-=10;
      delay_ms(100); // ch?ng nhi?u khi nh?n n�t
    }

    // Hi?n th? thi?t l?p kho?ng c�ch
    lcd_gotoxy(1, 2);
    printf(lcd_putc, "THIET LAP:%u MM  ", thiet_lap);

    do_dac(); // �o �?c kho?ng c�ch 2 l?n li�n ti?p t�ng �? ch�nh x�c
    int32 kc32 = khoang_cach;
    kc32 *= 347  ;
    if (kc32 > 0)
      kc32 /= 104  ;

    lcd_gotoxy(11, 1); // ��a lcd v? d?ng 1 c?t 11
    if (kc32 <= 5000) {
      printf(lcd_putc, "%Ldmm   ", kc32 -34  ); // hi?n th? kho?ng c�ch l�n lcd
    }

    // K�ch ho?t buzzer n?u kho?ng c�ch nh? h�n thi?t l?p
    if (kc32 - 34  < thiet_lap) {
      output_high(BUZZER_PIN); // b?t buzzer
    } else {
      output_low(BUZZER_PIN); // t?t buzzer
    }
   // delay_ms(100); // c?p nh?t kho?ng c�ch sau 100ms

    // T�ng b? �?m th?i gian l�u
    thoi_gian_luu += 100; // t�ng l�n 100ms

    // Ki?m tra n?u �? qua 5 gi�y
    if(thoi_gian_luu >= 2000) {
      thoi_gian_luu = 0; // �?t l?i b? �?m th?i gian
      khoang_cach_luu = kc32- 34; // l�u kho?ng c�ch hi?n t?i
      luu_khoang_cach(khoang_cach_luu); // g?i h�m l�u kho?ng c�ch v�o m?ng

      // K�ch ho?t loa b�o hi?u �? l�u
      output_high(BUZZER_PIN);
      delay_ms(100); // th?i gian k�u
      output_low(BUZZER_PIN);
    }

    // Ki?m tra n�t xem
    if(input(VIEW_BUTTON) == 0) {
      delay_ms(100); // ch?ng nhi?u khi nh?n n�t
      xem_khoang_cach_da_luu(); // g?i h�m hi?n th? 20 l?n �o cu?i c�ng
    }
  }
}

//========================================
void do_dac() // �o kho?ng c�ch s? d?ng timer0 v� ng?t ngo�i
{
  delay_ms(200);
  kcl = kch = 0;
  khoang_cach = 0; // kho?ng c�ch t?c l� �o = 0
  output_low(trig); // b?t �?u ph�t t�n hi?u
  delay_us(10);
  output_high(trig); // d?ng ph�t t�n hi?u
  enable_interrupts(int_EXT); // cho ph�p ng?t ngo�i ho?t �?ng
  set_timer0(-150); // �?t l?i gi� tr? cho timer 0
  delay_us(100); // t?o th?i gian tr? 100 us cho �? tr? c?a c?m bi?n
  enable_interrupts(int_timer0); // cho ph�p ng?t timer 0
  delay_ms(100); // t?o tr? 400 ms cho t�n hi?u ph?n h?i
  disable_interrupts(int_timer0); // c?m ng?t timer 0
  disable_interrupts(int_ext); // c?m ng?t ngo�i
  khoang_cach = make16(kch, kcl);
  if (khoang_cach > 5000)
    khoang_cach = 5000;
}

//========================================
#int_timer0 // Ng?t sau 0.2x125x2 uS = 50uS t��ng ���ng 1 cm
void ngat_timer0() {
  set_timer0(-11); // n?p l?i gi� tr? cho timer0
  kcl++;
  if (kcl == 0) {
    kch++;
  }
}

//========================================
#INT_EXT // ng?t ngo�i
void Ngat_ngoai() {
  disable_interrupts(int_timer0); // c?m ng?t timer 0
}

